import Usuario from "../models/Usuario.js";
import passport from "passport";
import validateEmail from "email-check";

export const renderSignUpForm = (req, res) => res.render("auth/signup");

export const singup = async (req, res) => {
  let errors = [];
  const { rut, nombre, apellido, edad, email, telefono, direccion, password, confirm_password } = req.body;

  if (!rut) {
    errors.push({ text: "Porfavor ingrese rut." });
  }
  if(rut.length < 8 ){
    errors.push({ text: "El rut ingresado es muy corto"})
  }
  if (!nombre) {
    errors.push({ text: "Porfavor ingrese nombre." });
  }
  if (!apellido) {
    errors.push({ text: "Porfavor ingrese apellido" });
  }
  if (!edad) {
    errors.push({ text: "Porfavor ingrese edad" });
  }
  if (!email) {
    errors.push({ text: "Porfavor ingrese email" });
  }
  if (!telefono) {
    errors.push({ text: "Porfavor ingrese telefono de contacto" });
  }
  if (!direccion) {
    errors.push({ text: "Porfavor ingrese dirección" });
  }
  if (!password) {
    errors.push({ text: "Porfavor ingrese contraseña" });
  }
  if (!confirm_password) {
    errors.push({ text: "Porfavor confirme contraseña" });
  }
  if (password !== confirm_password) {
    errors.push({ text: "Las contraseñas no coinciden." });
  }

  if (password.length < 4) {
    errors.push({ text: "La contraseña debe tener mas de 4 caracteres" });
  }

  if (errors.length > 0) {
    return res.render("auth/signup", {
      errors,
      rut,
      nombre,
      apellido,
      edad,
      email,
      telefono,
      direccion,
      password,
      confirm_password,
    });
  }

  // Look for email coincidence
  const userFound = await Usuario.findOne({ email: email });
  if (userFound) {
    req.flash("error_msg", "Este email está en uso.");
    return res.redirect("/auth/signup");
  }

  //validar rut
  class RutValidador{
    constructor(rut) {
        this.rut = rut;
        //obtenemos el ultimo caracter del rut
        this.dv = rut.substring(this.rut.length - 1);
        //limpiar rut dejando solamente los numeros
        this.rut = this.rut.substring(0, this.rut.length - 1).replace(/\D/g, '');
        this.esValido = this.validar();
    }
    validar(){
        let numerosArray = this.rut.split('').reverse()
        let acumulador = 0;
        let multiplicador = 2;
        for (let numero of numerosArray){
            acumulador += parseInt(numero) * multiplicador;
            multiplicador++;

            if (multiplicador == 8){
                multiplicador = 2;
            }
        }

        let dv = 11 - (acumulador % 11);

        if (dv == 11)
            dv = '0'
        if (dv == 10)
            dv = 'k';

        return dv == this.dv.toLowerCase();
    } 
  }
  const validador = new RutValidador(rut)
  if (validador.esValido != true){
    req.flash("error_msg", "El rut ingresado no es válido.");
    return res.redirect("/auth/signup");
  }

    // coindencia de rut
    const rutFound = await Usuario.findOne({ rut: rut });
    if (rutFound) {
      req.flash("error_msg", "Este rut ya está registrado.");
      return res.redirect("/auth/signup");
    }

  // Saving a New User
  const newUser = new Usuario({rut, nombre, apellido, edad, email, telefono, direccion, password });
  newUser.password = await newUser.encryptPassword(password);
  await newUser.save();
  req.flash("success_msg", "Estás registrado.");
  res.redirect("/auth/signin");
};

export const renderSigninForm = (req, res) => res.render("auth/signin");

export const signin = passport.authenticate("local", {
  successRedirect: "/pymes",
  failureRedirect: "/auth/signin",
  failureFlash: true,
});

export const logout = async (req, res, next) => {
  await req.logout((err) => {
    if (err) return next(err);
    req.flash("success_msg", "Ahora estás desconectado.");
    res.redirect("/auth/signin");
  });
};
