import Pyme from "../models/Pyme.js";
import fs from 'fs';
import app from "../app.js";
export const renderPymeForm = (req, res) => res.render("pymes/new-pyme");

export const createNewPyme = async (req, res) => {
  const { nombre_pyme, telefono, ubicacion, descripcion, categoria, sitioWeb} = req.body;
  const errors = [];
  if (!nombre_pyme) {
    errors.push({ text: "Porfavor ingrese nombre de su pyme." });
  }
  if (!telefono) {
    errors.push({ text: "Porfavor ingrese telefono de contacto" });
  }
  if (!ubicacion) {
    errors.push({ text: "Porfavor ingrese ubicacion" });
  }
  if (!descripcion) {
    errors.push({ text: "Porfavor ingrese descripcion" });
  }
  if (!categoria) {
    errors.push({ text: "Porfavor ingrese su categoria" });
  }
  if (!req.files) {
    errors.push({ text: "Por favor seleccione una imagen" });
  }

  if (errors.length > 0)
    return res.render("pymes/new-pyme", {
      errors,
      nombre_pyme,
      telefono,
      ubicacion,
      descripcion,
      categoria,
      sitioWeb,
    });
  var base64data = (req.files.imagen.data).toString('base64');
  const newPyme = new Pyme({ nombre_pyme, telefono, ubicacion, descripcion, categoria, sitioWeb, base64data});
  newPyme.user = req.user.id;
  await newPyme.save();
  req.flash("success_msg", "Pyme agregada correctamente ");
  res.redirect("/pymes");
};

export const renderImgPyme = async (req, res) => {
  const imgPymes = await Pyme.find({ user: req.user.id },{ projection: { _id: 0, imageBuffer: 1} })
  const base64String = imgPymes.toString('base64');
  res.send(base64String);
};

export const renderPymes = async (req, res) => {
  const pymes = await Pyme.find({ user: req.user.id })
    .sort({ date: "desc" })
    .lean();
  res.render("pymes/all-pymes", { pymes });
};

export const renderPymess = async (req, res) => {
  const pymess = await Pyme.find({ user: req.user.id })
    .sort({ date: "desc" })
    .lean();
  res.render("pymes/all-pymes2", { pymess });
};

export const renderPymesss = async (req, res) => {
  const pymesss = await Pyme.find()
    .sort({ date: "desc" })
    .lean();
  res.render("pymes/all-pymes3", { pymesss });
};

export const renderEditForm = async (req, res) => {
  const pyme = await Pyme.findById(req.params.id).lean();
  if (pyme.user != req.user.id) {
    req.flash("error_msg", "No autorizado");
    return res.redirect("/pymes");
  }
  res.render("pymes/edit-pyme", { pyme });
};

export const updatePyme = async (req, res) => {
  const { nombre_pyme, telefono, ubicacion, descripcion, categoria, sitioWeb } = req.body;

  if (req.files && req.files.imagen && req.files.imagen.data) {
    var base64data = (req.files.imagen.data).toString('base64');
  }
    await Pyme.findByIdAndUpdate(req.params.id, { nombre_pyme, telefono, ubicacion, descripcion, categoria, sitioWeb, base64data });
    req.flash("success_msg", "Pyme actualizada correctamente");
    res.redirect("/pymes");
};

export const deletePyme = async (req, res) => {
  const pyme = await Pyme.findById(req.params.id);
  if (pyme.user == req.user.id) {
    await Pyme.findByIdAndDelete(req.params.id);
    req.flash("success_msg", "Pyme borrada correctamente");
    return res.redirect("/pymes");
  }
  req.flash("error_msg", "No autorizado");
  res.redirect("/pymes")
};

