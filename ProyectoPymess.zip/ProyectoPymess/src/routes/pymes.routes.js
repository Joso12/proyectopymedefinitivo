import Pyme from '../models/Pyme.js'
import { Router } from "express";
import {
  renderPymeForm,
  createNewPyme,
  renderPymes,
  renderPymess,
  renderPymesss,
  renderEditForm,
  updatePyme,
  deletePyme,
} from "../controllers/pymes.controller.js";
import { isAuthenticated } from "../helpers/auth.js";

const router = Router();

// New Pyme
router.get("/pymes/anadir", isAuthenticated, renderPymeForm);

router.post("/pymes/new-pyme", isAuthenticated, createNewPyme);

// Get All Pymes
router.get("/pymes", isAuthenticated, renderPymes);

router.get("/pymess/ver/:id", isAuthenticated, renderPymess);

router.get("/pymess/all-pymes2/:id", isAuthenticated, renderPymess);

router.get("/usuario", isAuthenticated, renderPymesss);

// Edit Pymes
router.get("/pymes/editar/:id", isAuthenticated, renderEditForm);

router.put("/pymes/edit-pyme/:id", isAuthenticated, updatePyme);

// Delete Pymes
router.delete("/pymes/borrar/:id", isAuthenticated, deletePyme);


router.get('/categoria', async (req, res) =>{
  const categoria = await Pyme.distinct('categoria');
  res.render('categoria',{categoria});
});

router.get('/pymes/categoria/:categoria', async (req,res) =>{    
  const categoria = await Pyme.find({'categoria':req.params.categoria}).lean();     
  res.render('pymes_categoria', {categoria});                    
});

router.get('/ubicacion', async (req,res) =>{    
  const ubicacion = await Pyme.distinct('ubicacion');     
  res.render('ubicacion', {ubicacion});                    
});


router.get('/pymes/ubicacion/:ubicacion', async (req,res) =>{    
  const ubicacion = await Pyme.find({'ubicacion':req.params.ubicacion}).lean();     
  res.render('pymes_ubicacion', {ubicacion});                    
});


export default router;


